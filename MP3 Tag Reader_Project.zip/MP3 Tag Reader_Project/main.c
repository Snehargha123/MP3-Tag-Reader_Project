#include "mp3tag.h"


/*
 * =========================================================
 * MAIN FUNCTION
 * =========================================================
 */

int main(int argc, char *argv[])
{
    /*
     * -----------------------------------------------------
     * Check minimum command-line arguments.
     *
     * VIEW:
     *
     * ./mp3tag.exe -v sample.mp3
     *
     * argc = 3
     *
     *
     * EDIT:
     *
     * ./mp3tag.exe -e -t "New Title" sample.mp3
     *
     * argc = 5
     * -----------------------------------------------------
     */

    if (argc < 3)
    {
        printf("\n");
        printf("ERROR: Insufficient command-line arguments.\n");

        print_usage(argv[0]);

        return -1;
    }


    /*
     * =====================================================
     * VIEW OPERATION
     * =====================================================
     *
     * ./mp3tag.exe -v sample.mp3
     */

    if (strcmp(argv[1], "-v") == 0)
    {
        /*
         * VIEW requires exactly:
         *
         * argv[0] -> program
         * argv[1] -> -v
         * argv[2] -> filename
         */

        if (argc != 3)
        {
            printf("\n");
            printf("ERROR: Invalid arguments for VIEW.\n");

            printf("\nCorrect format:\n");
            printf("    %s -v sample.mp3\n",
                   argv[0]);

            return -1;
        }


        /*
         * Check MP3 extension.
         */

        if (!check_mp3_extension(argv[2]))
        {
            printf("\n");
            printf("ERROR: File must have .mp3 extension.\n");

            return -1;
        }


        /*
         * Call VIEW function.
         */

        return mp3view(argv[2]);
    }


    /*
     * =====================================================
     * EDIT OPERATION
     * =====================================================
     *
     * ./mp3tag.exe -e -t "New Title" sample.mp3
     */

    if (strcmp(argv[1], "-e") == 0)
    {
        /*
         * EDIT requires:
         *
         * argv[0] -> program
         * argv[1] -> -e
         * argv[2] -> -t/-a/-A/-y/-m/-c
         * argv[3] -> new value
         * argv[4] -> filename
         *
         * Therefore argc must be 5.
         */

        if (argc != 5)
        {
            printf("\n");
            printf("ERROR: Invalid arguments for EDIT.\n");

            printf("\nCorrect formats:\n");

            printf("    %s -e -t \"New Title\" sample.mp3\n",
                   argv[0]);

            printf("    %s -e -a \"New Artist\" sample.mp3\n",
                   argv[0]);

            printf("    %s -e -A \"New Album\" sample.mp3\n",
                   argv[0]);

            printf("    %s -e -y \"2026\" sample.mp3\n",
                   argv[0]);

            printf("    %s -e -m \"Rock\" sample.mp3\n",
                   argv[0]);

            printf("    %s -e -c \"New Comment\" sample.mp3\n",
                   argv[0]);

            return -1;
        }


        /*
         * -------------------------------------------------
         * Check edit option.
         * -------------------------------------------------
         */

        if (strcmp(argv[2], "-t") != 0 &&
            strcmp(argv[2], "-a") != 0 &&
            strcmp(argv[2], "-A") != 0 &&
            strcmp(argv[2], "-y") != 0 &&
            strcmp(argv[2], "-m") != 0 &&
            strcmp(argv[2], "-c") != 0)
        {
            printf("\n");
            printf("ERROR: Invalid edit option '%s'.\n",
                   argv[2]);

            printf("\nValid options are:\n");

            printf("    -t  Title\n");
            printf("    -a  Artist\n");
            printf("    -A  Album\n");
            printf("    -y  Year\n");
            printf("    -m  Music / Genre\n");
            printf("    -c  Comment\n");

            return -1;
        }


        /*
         * -------------------------------------------------
         * Check MP3 extension.
         * -------------------------------------------------
         */

        if (!check_mp3_extension(argv[4]))
        {
            printf("\n");
            printf("ERROR: File must have .mp3 extension.\n");

            return -1;
        }


        /*
         * -------------------------------------------------
         * Check that new value is not empty.
         * -------------------------------------------------
         */

        if (strlen(argv[3]) == 0)
        {
            printf("\n");
            printf("ERROR: New value cannot be empty.\n");

            return -1;
        }


        /*
         * -------------------------------------------------
         * Call EDIT function.
         * -------------------------------------------------
         */

        return mp3edit(argv[4],
                       argv[2],
                       argv[3]);
    }


    /*
     * =====================================================
     * INVALID COMMAND
     * =====================================================
     */

    printf("\n");
    printf("ERROR: Invalid operation '%s'.\n",
           argv[1]);

    print_usage(argv[0]);

    return -1;
}