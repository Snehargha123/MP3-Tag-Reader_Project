#include "mp3tag.h"

/*
 * =========================================================
 * Convert 4-byte Big Endian frame size
 * =========================================================
 */
static uint32_t get_frame_size(unsigned char size_bytes[4])
{
    return ((uint32_t)size_bytes[0] << 24) |
           ((uint32_t)size_bytes[1] << 16) |
           ((uint32_t)size_bytes[2] << 8)  |
           ((uint32_t)size_bytes[3]);
}


/*
 * =========================================================
 * Convert frame ID from edit option
 *
 * -t -> TIT2 -> Title
 * -a -> TPE1 -> Artist
 * -A -> TALB -> Album
 * -y -> TYER -> Year
 * -m -> TCON -> Music/Genre
 * =========================================================
 */
static const char *get_frame_id(const char *option)
{
    if (strcmp(option, "-t") == 0)
        return "TIT2";

    if (strcmp(option, "-a") == 0)
        return "TPE1";

    if (strcmp(option, "-A") == 0)
        return "TALB";

    if (strcmp(option, "-y") == 0)
        return "TYER";

    if (strcmp(option, "-m") == 0)
        return "TCON";

    return NULL;
}


/*
 * =========================================================
 * Get field name
 * =========================================================
 */
static const char *get_field_name(const char *option)
{
    if (strcmp(option, "-t") == 0)
        return "Title";

    if (strcmp(option, "-a") == 0)
        return "Artist";

    if (strcmp(option, "-A") == 0)
        return "Album";

    if (strcmp(option, "-y") == 0)
        return "Year";

    if (strcmp(option, "-m") == 0)
        return "Music";

    if (strcmp(option, "-c") == 0)
        return "Comment";

    return "Unknown";
}


/*
 * =========================================================
 * EDIT MP3 FILE
 * =========================================================
 */
int mp3edit(const char *filename,
            const char *option,
            const char *new_value)
{
    FILE *fp;

    unsigned char header[10];

    char frame_id[5];

    unsigned char size_bytes[4];

    unsigned char flags[2];

    uint32_t frame_size;

    const char *required_frame;

    size_t new_length;

    int found_count = 0;

    int updated_count = 0;


    /*
     * -----------------------------------------------------
     * COMMENT is not handled yet.
     *
     * COMM is structurally different from normal
     * text frames.
     * -----------------------------------------------------
     */
    if (strcmp(option, "-c") == 0)
    {
        printf("\n");
        printf("ERROR: Comment editing is not implemented yet.\n");

        return -1;
    }


    /*
     * -----------------------------------------------------
     * Get required frame ID.
     * -----------------------------------------------------
     */
    required_frame = get_frame_id(option);

    if (required_frame == NULL)
    {
        printf("\n");
        printf("ERROR: Invalid edit option: %s\n",
               option);

        return -1;
    }


    /*
     * -----------------------------------------------------
     * Open MP3 in read + write binary mode.
     * -----------------------------------------------------
     */
    fp = fopen(filename, "r+b");

    if (fp == NULL)
    {
        printf("\n");
        printf("ERROR: Cannot open file: %s\n",
               filename);

        return -1;
    }


    /*
     * -----------------------------------------------------
     * Check ID3v2.3.
     * -----------------------------------------------------
     */
    if (!check_id3v23(fp))
    {
        printf("\n");
        printf("ERROR: ID3v2.3 tag not found.\n");

        fclose(fp);

        return -1;
    }


    printf("\n");
    printf("ID3v2.3 tag detected successfully.\n");


    /*
     * -----------------------------------------------------
     * Read ID3 header.
     * -----------------------------------------------------
     */
    fseek(fp, 0, SEEK_SET);

    if (fread(header, 1, 10, fp) != 10)
    {
        printf("ERROR: Unable to read ID3 header.\n");

        fclose(fp);

        return -1;
    }


    /*
     * -----------------------------------------------------
     * Move after 10-byte ID3 header.
     * -----------------------------------------------------
     */
    if (fseek(fp, ID3_HEADER_SIZE, SEEK_SET) != 0)
    {
        printf("ERROR: Unable to skip ID3 header.\n");

        fclose(fp);

        return -1;
    }


    /*
     * -----------------------------------------------------
     * New frame data:
     *
     * First byte = text encoding
     * Remaining bytes = new string
     *
     * Example:
     *
     * "Dil hai"
     *
     * 00 D i l   h a i
     * ^  ^
     * |  |
     * |  text
     * encoding
     * -----------------------------------------------------
     */
    new_length = strlen(new_value) + 1;


    /*
     * -----------------------------------------------------
     * Search all frames.
     * -----------------------------------------------------
     */
    while (1)
    {
        long frame_data_position;

        /*
         * Read Frame ID.
         */
        if (fread(frame_id, 1, 4, fp) != 4)
        {
            break;
        }

        frame_id[4] = '\0';


        /*
         * Padding means end of frames.
         */
        if (frame_id[0] == '\0')
        {
            break;
        }


        /*
         * Read frame size.
         */
        if (fread(size_bytes, 1, 4, fp) != 4)
        {
            printf("ERROR: Unable to read frame size.\n");

            fclose(fp);

            return -1;
        }

        frame_size = get_frame_size(size_bytes);


        /*
         * Read frame flags.
         */
        if (fread(flags, 1, 2, fp) != 2)
        {
            printf("ERROR: Unable to read frame flags.\n");

            fclose(fp);

            return -1;
        }


        /*
         * Current position = beginning of frame data.
         */
        frame_data_position = ftell(fp);


        /*
         * -------------------------------------------------
         * Check selected frame.
         * -------------------------------------------------
         */
        if (strcmp(frame_id, required_frame) == 0)
        {
            unsigned char *new_frame_data;

            found_count++;


            printf("\n");
            printf("Frame found\n");
            printf("--------------------------------------------\n");

            printf("Frame ID       : %s\n",
                   frame_id);

            printf("Field          : %s\n",
                   get_field_name(option));

            printf("Existing size  : %u bytes\n",
                   frame_size);

            printf("Frame flags    : %02X %02X\n",
                   flags[0],
                   flags[1]);


            /*
             * -------------------------------------------------
             * Check if new value fits.
             * -------------------------------------------------
             */
            if (new_length > frame_size)
            {
                printf("\n");
                printf("ERROR: New value is too large.\n");

                printf("Existing size : %u bytes\n",
                       frame_size);

                printf("Required size : %lu bytes\n",
                       (unsigned long)new_length);

                printf("Frame NOT modified.\n");


                /*
                 * Move to next frame.
                 */
                if (fseek(fp,
                          frame_data_position +
                          (long)frame_size,
                          SEEK_SET) != 0)
                {
                    fclose(fp);
                    return -1;
                }

                continue;
            }


            /*
             * -------------------------------------------------
             * Allocate same size as existing frame.
             * -------------------------------------------------
             */
            new_frame_data = calloc(frame_size, 1);

            if (new_frame_data == NULL)
            {
                printf("ERROR: Memory allocation failed.\n");

                fclose(fp);

                return -1;
            }


            /*
             * -------------------------------------------------
             * Encoding byte.
             *
             * 00 = ISO-8859-1
             * -------------------------------------------------
             */
            new_frame_data[0] = 0;


            /*
             * -------------------------------------------------
             * Copy new text.
             * -------------------------------------------------
             */
            memcpy(&new_frame_data[1],
                   new_value,
                   strlen(new_value));


            /*
             * -------------------------------------------------
             * Move to beginning of frame data.
             * -------------------------------------------------
             */
            if (fseek(fp,
                      frame_data_position,
                      SEEK_SET) != 0)
            {
                printf("ERROR: Unable to seek to frame data.\n");

                free(new_frame_data);

                fclose(fp);

                return -1;
            }


            /*
             * -------------------------------------------------
             * Write complete frame data.
             * -------------------------------------------------
             */
            if (fwrite(new_frame_data,
                       1,
                       frame_size,
                       fp) != frame_size)
            {
                printf("ERROR: Failed to write frame data.\n");

                free(new_frame_data);

                fclose(fp);

                return -1;
            }


            /*
             * -------------------------------------------------
             * Flush data from C library buffer.
             * -------------------------------------------------
             */
            if (fflush(fp) != 0)
            {
                printf("ERROR: fflush() failed.\n");

                free(new_frame_data);

                fclose(fp);

                return -1;
            }


            /*
             * -------------------------------------------------
             * Verify by reading the same bytes back.
             * -------------------------------------------------
             */
            {
                unsigned char *verify_data;

                verify_data = malloc(frame_size);

                if (verify_data == NULL)
                {
                    printf("ERROR: Verification allocation failed.\n");

                    free(new_frame_data);

                    fclose(fp);

                    return -1;
                }


                /*
                 * Go back to beginning of frame data.
                 */
                if (fseek(fp,
                          frame_data_position,
                          SEEK_SET) != 0)
                {
                    printf("ERROR: Verification seek failed.\n");

                    free(verify_data);
                    free(new_frame_data);

                    fclose(fp);

                    return -1;
                }


                /*
                 * Read data again.
                 */
                if (fread(verify_data,
                          1,
                          frame_size,
                          fp) != frame_size)
                {
                    printf("ERROR: Verification read failed.\n");

                    free(verify_data);
                    free(new_frame_data);

                    fclose(fp);

                    return -1;
                }


                /*
                 * Display bytes for debugging.
                 */
                printf("\nWritten frame data:\n");

                for (uint32_t i = 0; i < frame_size; i++)
                {
                    printf("%02X ",
                           verify_data[i]);
                }

                printf("\n");


                /*
                 * Display text.
                 */
                printf("Written text : ");

                for (uint32_t i = 1;
                     i < frame_size;
                     i++)
                {
                    if (verify_data[i] == '\0')
                    {
                        break;
                    }

                    printf("%c",
                           verify_data[i]);
                }

                printf("\n");


                /*
                 * -------------------------------------------------
                 * Verify actual contents.
                 * -------------------------------------------------
                 */
                if (verify_data[0] == 0 &&
                    memcmp(&verify_data[1],
                           new_value,
                           strlen(new_value)) == 0)
                {
                    printf("Verification  : SUCCESS\n");

                    updated_count++;
                }
                else
                {
                    printf("Verification  : FAILED\n");
                }


                free(verify_data);
            }


            free(new_frame_data);


            /*
             * -------------------------------------------------
             * Move to beginning of next frame.
             *
             * frame_data_position points to the current
             * frame's data.
             * -------------------------------------------------
             */
            if (fseek(fp,
                      frame_data_position +
                      (long)frame_size,
                      SEEK_SET) != 0)
            {
                printf("ERROR: Unable to move to next frame.\n");

                fclose(fp);

                return -1;
            }
        }
        else
        {
            /*
             * -------------------------------------------------
             * Not the required frame.
             *
             * Skip its data.
             * -------------------------------------------------
             */
            if (fseek(fp,
                      frame_data_position +
                      (long)frame_size,
                      SEEK_SET) != 0)
            {
                printf("ERROR: Unable to skip frame data.\n");

                fclose(fp);

                return -1;
            }
        }
    }


    /*
     * =========================================================
     * Final result
     * =========================================================
     */

    printf("\n");
    printf("============================================\n");
    printf("             EDIT RESULT\n");
    printf("============================================\n");

    printf("Frame ID       : %s\n",
           required_frame);

    printf("Field          : %s\n",
           get_field_name(option));

    printf("New value      : %s\n",
           new_value);

    printf("Frames found   : %d\n",
           found_count);

    printf("Frames updated : %d\n",
           updated_count);


    if (updated_count > 0)
    {
        printf("--------------------------------------------\n");
        printf("          EDIT SUCCESSFUL\n");
    }
    else
    {
        printf("--------------------------------------------\n");
        printf("          EDIT FAILED\n");
    }

    printf("============================================\n");


    /*
     * Close file.
     */
    fclose(fp);


    if (updated_count > 0)
    {
        return 0;
    }

    return -1;
}