#ifndef MP3TAG_H
#define MP3TAG_H

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#define ID3_HEADER_SIZE 10

#define TITLE_SIZE   256
#define ARTIST_SIZE  256
#define ALBUM_SIZE   256
#define YEAR_SIZE    32
#define GENRE_SIZE   256
#define COMMENT_SIZE 512

typedef struct
{
    char title[TITLE_SIZE];
    char artist[ARTIST_SIZE];
    char album[ALBUM_SIZE];
    char year[YEAR_SIZE];
    char genre[GENRE_SIZE];
    char comment[COMMENT_SIZE];

} MP3Tag;


/* View */
int mp3view(const char *filename);


/* Edit */
int mp3edit(const char *filename,
            const char *option,
            const char *new_value);


/* Utility functions */
int check_id3v23(FILE *fp);
int check_mp3_extension(const char *filename);
void print_usage(const char *program);

#endif