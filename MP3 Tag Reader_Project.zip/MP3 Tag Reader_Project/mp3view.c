#include "mp3tag.h"


/*
 * =========================================================
 * Display usage
 * =========================================================
 */

void print_usage(const char *program)
{
    printf("\n");
    printf("====================================================\n");
    printf("             MP3 TAG READER AND EDITOR\n");
    printf("====================================================\n");

    printf("\nVIEW:\n");
    printf("    %s -v sample.mp3\n", program);

    printf("\nEDIT:\n");
    printf("    %s -e -t \"New Title\" sample.mp3\n", program);
    printf("    %s -e -a \"New Artist\" sample.mp3\n", program);
    printf("    %s -e -A \"New Album\" sample.mp3\n", program);
    printf("    %s -e -y \"2026\" sample.mp3\n", program);
    printf("    %s -e -m \"Rock\" sample.mp3\n", program);
    printf("    %s -e -c \"New Comment\" sample.mp3\n", program);
}


/*
 * =========================================================
 * Check .mp3 extension
 * =========================================================
 */

int check_mp3_extension(const char *filename)
{
    const char *extension;

    extension = strrchr(filename, '.');

    if (extension == NULL)
    {
        return 0;
    }

    if (strcmp(extension, ".mp3") == 0 ||
        strcmp(extension, ".MP3") == 0)
    {
        return 1;
    }

    return 0;
}


/*
 * =========================================================
 * Check ID3v2.3
 * =========================================================
 */

int check_id3v23(FILE *fp)
{
    unsigned char header[10];

    /*
     * Move to beginning.
     */
    if (fseek(fp, 0, SEEK_SET) != 0)
    {
        return 0;
    }

    /*
     * Read 10-byte ID3 header.
     */
    if (fread(header, 1, 10, fp) != 10)
    {
        return 0;
    }

    /*
     * Display first 10 bytes.
     */
    printf("\nFirst 10 bytes of MP3 file:\n");

    for (int i = 0; i < 10; i++)
    {
        printf("%02X ", header[i]);
    }

    printf("\n");


    /*
     * Check "ID3".
     */
    if (header[0] != 'I' ||
        header[1] != 'D' ||
        header[2] != '3')
    {
        return 0;
    }


    /*
     * Check ID3v2.3.
     *
     * header[3] = 03
     * header[4] = 00
     */
    if (header[3] != 0x03 ||
        header[4] != 0x00)
    {
        return 0;
    }

    return 1;
}


/*
 * =========================================================
 * Convert normal Big Endian 4-byte size
 * =========================================================
 */

static uint32_t get_frame_size(unsigned char size_bytes[4])
{
    return ((uint32_t)size_bytes[0] << 24) |
           ((uint32_t)size_bytes[1] << 16) |
           ((uint32_t)size_bytes[2] << 8)  |
           ((uint32_t)size_bytes[3]);
}


/*
 * =========================================================
 * Convert ID3 tag size
 *
 * ID3v2.3 tag size uses SYNCSAFE integer:
 *
 * 7 bits from each byte.
 *
 * =========================================================
 */

static uint32_t get_tag_size(unsigned char size_bytes[4])
{
    return ((uint32_t)(size_bytes[0] & 0x7F) << 21) |
           ((uint32_t)(size_bytes[1] & 0x7F) << 14) |
           ((uint32_t)(size_bytes[2] & 0x7F) << 7)  |
           ((uint32_t)(size_bytes[3] & 0x7F));
}


/*
 * =========================================================
 * Copy normal text frame
 *
 * For:
 *
 * TIT2
 * TPE1
 * TALB
 * TYER
 * TCON
 *
 * Frame data:
 *
 * Byte 0     -> Encoding
 * Byte 1...  -> Text
 * =========================================================
 */

static void copy_text(char *destination,
                      size_t destination_size,
                      unsigned char *frame_data,
                      uint32_t frame_size)
{
    size_t length;

    if (frame_size <= 1)
    {
        destination[0] = '\0';
        return;
    }


    /*
     * Skip encoding byte.
     */
    length = frame_size - 1;


    /*
     * Prevent buffer overflow.
     */
    if (length >= destination_size)
    {
        length = destination_size - 1;
    }


    memcpy(destination,
           &frame_data[1],
           length);

    destination[length] = '\0';
}


/*
 * =========================================================
 * Read COMM comment
 *
 * ID3v2.3 COMM structure:
 *
 * Byte 0       -> Encoding
 * Byte 1-3     -> Language
 * Following    -> Description
 * Remaining    -> Comment
 *
 * =========================================================
 */

static void copy_comment(char *destination,
                         size_t destination_size,
                         unsigned char *frame_data,
                         uint32_t frame_size)
{
    size_t i;
    size_t length;


    /*
     * Need at least:
     *
     * 1 encoding
     * 3 language
     */
    if (frame_size <= 4)
    {
        destination[0] = '\0';
        return;
    }


    /*
     * Description starts at byte 4.
     */
    i = 4;


    /*
     * Find end of description.
     *
     * This handles the common ISO-8859-1
     * case where description is NULL terminated.
     */
    while (i < frame_size &&
           frame_data[i] != '\0')
    {
        i++;
    }


    /*
     * Skip NULL terminator.
     */
    if (i < frame_size)
    {
        i++;
    }


    /*
     * Remaining bytes = comment.
     */
    if (i >= frame_size)
    {
        destination[0] = '\0';
        return;
    }


    length = frame_size - i;


    if (length >= destination_size)
    {
        length = destination_size - 1;
    }


    memcpy(destination,
           &frame_data[i],
           length);

    destination[length] = '\0';
}


/*
 * =========================================================
 * Display final metadata
 * =========================================================
 */

static void display_tag(MP3Tag *tag)
{
    printf("\n");

    printf("----------------SELECTED VIEW DETAILS----------------\n");

    printf("\n");

    printf("------------------------------------------------------\n");

    printf("             MP3 TAG READER AND EDITOR FOR ID3v2\n");

    printf("------------------------------------------------------\n");

    printf("TITLE     : %s\n",
           tag->title[0] ?
           tag->title :
           "Not Found");

    printf("ARTIST    : %s\n",
           tag->artist[0] ?
           tag->artist :
           "Not Found");

    printf("ALBUM     : %s\n",
           tag->album[0] ?
           tag->album :
           "Not Found");

    printf("YEAR      : %s\n",
           tag->year[0] ?
           tag->year :
           "Not Found");

    printf("MUSIC     : %s\n",
           tag->genre[0] ?
           tag->genre :
           "Not Found");

    printf("COMMENT   : %s\n",
           tag->comment[0] ?
           tag->comment :
           "Not Found");

    printf("------------------------------------------------------\n");

    printf("--------------DETAILS DISPLAYED SUCCESSFULLY----------\n");
}


/*
 * =========================================================
 * VIEW MP3
 * =========================================================
 */

int mp3view(const char *filename)
{
    FILE *fp;

    unsigned char header[10];

    unsigned char tag_size_bytes[4];

    uint32_t tag_size;

    uint32_t bytes_read_from_tag = 0;

    char frame_id[5];

    unsigned char size_bytes[4];

    unsigned char flags[2];

    uint32_t frame_size;

    unsigned char *frame_data;

    MP3Tag tag;


    /*
     * Initialize structure.
     */
    memset(&tag, 0, sizeof(MP3Tag));


    /*
     * -----------------------------------------------------
     * Open MP3 in read-binary mode.
     * -----------------------------------------------------
     */
    fp = fopen(filename, "rb");

    if (fp == NULL)
    {
        printf("ERROR: Cannot open '%s'.\n",
               filename);

        return -1;
    }


    /*
     * -----------------------------------------------------
     * Check ID3v2.3.
     * -----------------------------------------------------
     */
    if (!check_id3v23(fp))
    {
        printf("ERROR: ID3v2.3 tag not found.\n");

        fclose(fp);

        return -1;
    }


    printf("\nID3v2.3 tag detected successfully.\n");


    /*
     * -----------------------------------------------------
     * Read complete 10-byte header.
     * -----------------------------------------------------
     */
    if (fseek(fp, 0, SEEK_SET) != 0)
    {
        printf("ERROR: Unable to seek to file beginning.\n");

        fclose(fp);

        return -1;
    }


    if (fread(header, 1, 10, fp) != 10)
    {
        printf("ERROR: Unable to read ID3 header.\n");

        fclose(fp);

        return -1;
    }


    /*
     * -----------------------------------------------------
     * Get ID3 tag size.
     *
     * Bytes 6-9.
     * -----------------------------------------------------
     */
    memcpy(tag_size_bytes,
           &header[6],
           4);


    tag_size = get_tag_size(tag_size_bytes);


    printf("\nID3 Tag Size : %u bytes\n",
           tag_size);


    /*
     * -----------------------------------------------------
     * Move after 10-byte header.
     * -----------------------------------------------------
     */
    if (fseek(fp,
              ID3_HEADER_SIZE,
              SEEK_SET) != 0)
    {
        printf("ERROR: Unable to skip ID3 header.\n");

        fclose(fp);

        return -1;
    }


    /*
     * -----------------------------------------------------
     * Read frames only within ID3 tag.
     * -----------------------------------------------------
     */
    while (bytes_read_from_tag < tag_size)
    {
        /*
         * Need at least 10 bytes for another frame header.
         */
        if (tag_size - bytes_read_from_tag < 10)
        {
            break;
        }


        /*
         * -------------------------------------------------
         * Read Frame ID.
         * -------------------------------------------------
         */
        if (fread(frame_id, 1, 4, fp) != 4)
        {
            break;
        }

        frame_id[4] = '\0';

        bytes_read_from_tag += 4;


        /*
         * -------------------------------------------------
         * Padding / end of frames.
         * -------------------------------------------------
         */
        if (frame_id[0] == '\0')
        {
            break;
        }


        /*
         * -------------------------------------------------
         * Read frame size.
         * -------------------------------------------------
         */
        if (fread(size_bytes, 1, 4, fp) != 4)
        {
            break;
        }

        bytes_read_from_tag += 4;


        frame_size = get_frame_size(size_bytes);


        /*
         * -------------------------------------------------
         * Read flags.
         * -------------------------------------------------
         */
        if (fread(flags, 1, 2, fp) != 2)
        {
            break;
        }

        bytes_read_from_tag += 2;


        /*
         * -------------------------------------------------
         * Validate frame size.
         * -------------------------------------------------
         */
        if (frame_size >
            tag_size - bytes_read_from_tag)
        {
            printf("ERROR: Invalid frame size for %s.\n",
                   frame_id);

            break;
        }


        /*
         * -------------------------------------------------
         * Allocate frame data.
         * -------------------------------------------------
         */
        frame_data = NULL;

        if (frame_size > 0)
        {
            frame_data = malloc(frame_size);

            if (frame_data == NULL)
            {
                printf("ERROR: Memory allocation failed.\n");

                fclose(fp);

                return -1;
            }


            /*
             * Read frame data.
             */
            if (fread(frame_data,
                      1,
                      frame_size,
                      fp) != frame_size)
            {
                printf("ERROR: Unable to read frame data.\n");

                free(frame_data);

                fclose(fp);

                return -1;
            }
        }

        bytes_read_from_tag += frame_size;


        /*
         * =================================================
         * TIT2 → TITLE
         *
         * Only FIRST occurrence is used.
         * =================================================
         */
        if (strcmp(frame_id, "TIT2") == 0)
        {
            if (tag.title[0] == '\0')
            {
                copy_text(tag.title,
                          sizeof(tag.title),
                          frame_data,
                          frame_size);
            }
        }


        /*
         * =================================================
         * TPE1 → ARTIST
         * =================================================
         */
        else if (strcmp(frame_id, "TPE1") == 0)
        {
            if (tag.artist[0] == '\0')
            {
                copy_text(tag.artist,
                          sizeof(tag.artist),
                          frame_data,
                          frame_size);
            }
        }


        /*
         * =================================================
         * TALB → ALBUM
         * =================================================
         */
        else if (strcmp(frame_id, "TALB") == 0)
        {
            if (tag.album[0] == '\0')
            {
                copy_text(tag.album,
                          sizeof(tag.album),
                          frame_data,
                          frame_size);
            }
        }


        /*
         * =================================================
         * TYER → YEAR
         * =================================================
         */
        else if (strcmp(frame_id, "TYER") == 0)
        {
            if (tag.year[0] == '\0')
            {
                copy_text(tag.year,
                          sizeof(tag.year),
                          frame_data,
                          frame_size);
            }
        }


        /*
         * =================================================
         * TCON → MUSIC / GENRE
         * =================================================
         */
        else if (strcmp(frame_id, "TCON") == 0)
        {
            if (tag.genre[0] == '\0')
            {
                copy_text(tag.genre,
                          sizeof(tag.genre),
                          frame_data,
                          frame_size);
            }
        }


        /*
         * =================================================
         * COMM → COMMENT
         * =================================================
         */
        else if (strcmp(frame_id, "COMM") == 0)
        {
            if (tag.comment[0] == '\0')
            {
                copy_comment(tag.comment,
                             sizeof(tag.comment),
                             frame_data,
                             frame_size);
            }
        }


        /*
         * Free frame data.
         */
        free(frame_data);
    }


    /*
     * -----------------------------------------------------
     * Display final information.
     * -----------------------------------------------------
     */
    display_tag(&tag);


    /*
     * -----------------------------------------------------
     * Close file.
     * -----------------------------------------------------
     */
    fclose(fp);


    return 0;
}